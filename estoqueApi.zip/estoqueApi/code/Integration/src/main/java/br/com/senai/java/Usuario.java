package br.com.senai.java;

public class Usuario {
    int idUsuario;
    String nomeUsuario;
    String usuario;
    String senha;
    
}