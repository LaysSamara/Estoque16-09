const carregarItens = async () => {
    
    const response = await fetch('http://localhost:8080/listarItens')
    const dados = await response.json()
    console.log(dados)

    dados.forEach (item => {
        const containerItensElement = document.getElementById('container-itens')

        const template = document.getElementById('item-template')

        const itemElement = document.importNode(template.content, true)

        const itens_span = itemElement.querySelectorAll('span')

        itens_span[0].innerText = item.id_item
        itens_span[1].innerText = item.nome_item
        itens_span[2].innerText = item.descricao
        itens_span[3].innerText = item.quantidade
        itens_span[4].innerText = item.valor
        itens_span[5].innerText = item.setor

        containerItensElement.append(itemElement)
    })

}

window.onload = () => {
    carregarItens()

    console.log('Listar itens')
}