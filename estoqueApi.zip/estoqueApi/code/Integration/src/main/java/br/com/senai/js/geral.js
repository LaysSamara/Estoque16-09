const novo = async () => {
  const form = document.getElementById("form");
  const codigo = document.getElementById("codigo");
  const nomeElement = document.getElementById("nome");
  const descricaoElement = document.getElementById("descricao");
  const quantidadeElement = document.getElementById("quantidade");
  const valorElement = document.getElementById("valor");
  const setorElement = document.getElementById("setor");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
  
    checkInputs();
  });

  function checkInputs() {
    const codigoValue = codigo.value;
    const nomeElementValue = nomeElement.value;
    const descricaoElementValue = descricaoElement.value;
    const quantidadeElementValue = quantidadeElement.value;
    const valorElementValue = valorElement.value;
    const setorElementValue = setorElement.value;
    
    if (codigoValue === "") {
      setErrorFor(codigo, "O código do item é obrigatório.");
    } else {
      setSuccessFor(codigo);
    }
  
    if (nomeElementValue === "") {
      setErrorFor(nomeElement, "O nome do item é obrigatório.");
    } else {
      setSuccessFor(nomeElement);
    }
  
    if (descricaoElementValue === "") {
      setErrorFor(descricaoElement, "A descrição do produto é obrigatória.");
    } else {
      setSuccessFor(descricaoElement);
    }
  
    if (quantidadeElementValue === "") {
      setErrorFor(quantidadeElement, "A quantidade é obrigatória.");
    } else {
      setSuccessFor(quantidadeElement);
    }
  
    if (valorElementValue === "") {
      setErrorFor(valorElement, "O valor do item é obrigatório.");
    } else {
      setSuccessFor(valorElement);
    }
  
    if (setorElementValue === "") {
      setErrorFor(setorElement, "O setor do produto é obrigatório.");
    } else {
      setSuccessFor(setorElement);
    }
  
    const formControls = form.querySelectorAll(".form-control");
  
    const formIsValid = [...formControls].every((formControl) => {
      return formControl.className === "form-control success";
    });
  
    if (formIsValid) {
      window.location.replace("../html/adicionado.html")
    }
  }
}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector("small");

  // Adiciona a mensagem de erro
  small.innerText = message;

  // Adiciona a classe de erro
  formControl.className = "form-control error";
}

function setSuccessFor(input) {
  const formControl = input.parentElement;

  // Adicionar a classe de sucesso
  formControl.className = "form-control success";
}