package br.com.senai.java;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Routes extends RouteBuilder {

    @Override
    public void configure() throws Exception {

    restConfiguration()
        .enableCORS(true)
        .corsAllowCredentials(true)
        .corsHeaderProperty("Access-Control-Allow-Origin", "*")
        .corsHeaderProperty("Access-Control-Allow-Headers", "id_item, nome, content-type");

        JacksonDataFormat format = new JacksonDataFormat();
        format.setUnmarshalType(Usuario[].class);
        ObjectMapper mapper = new ObjectMapper();
        format.setObjectMapper(mapper);

        rest()
            .post("/adicionarItem")
                    .to("direct:adicionarJson")
            .get("/listarItem")
                .to("direct:listarJson")
            .get("/listarItens")
                .to("direct:listarTodos")
            .put("/editarItem")
                .to("direct:editarJson")
            .delete("/excluirItem")
                .to("direct:excluirJson")
        ;

        rest()
            .post("/adicionarUsuario")
                    .to("direct:novoUsuario")
        ;

        //adicionarItem
        from("direct:adicionarJson")
            .to("sql:insert into item (nome_item,quantidade,valor,setor) values (:#nome_item,:#quantidade,:#valor,:#setor);")
        ;

        //listarItem
        from("direct:listarJson")
            // .process(e -> {
            //     System.out.println("lays beauty");
            // })
            .to("sql:select * from item where id_item=:#id_item;")
            //vira json
            .marshal(format)
            .log("${body}")
        ; 

        //listarItens
        from("direct:listarTodos")
            .log("${body}")
            .to("sql:select * from item;")
            .marshal(format)
            .log("${body}")
        ; 

        //editarItem
        from("direct:editarJson")
            .log("${body}")
            .to("sql:update item set nome_item=:#nome_item, descricao=:#descricao, quantidade=:#quantidade, valor=:#valor, setor=:#setor where id_item=:#id_item;")
            .marshal(format)
            .log("${body}")
        ;

        //excluirItem
        from("direct:excluirJson")
            .log("${body}")
            .to("sql:delete from item where id_item=:#id_item;")
            .marshal(format)
            .log("${body}")
        ;

        //adicionarUsuario
        from("direct:novoUsuario")
            .to("sql:insert into usuario (nome_usuario,usuario,senha) values (:#nome_usuario,:#usuario,:#senha);")
        ;
    }
}