package br.com.senai.java;

public class Item {
    int id_item;
    String nome_item; 
    String descricao; 
    int quantidade; 
    double valor;
    String setor;
    int data_entrada;
}
